#pragma once
#include <string>
using namespace std;
class Shape
{
public:
    Shape()
    {
        id = "Shape";
    }
    ~Shape()
    {
    }
    string id;
};
