#include "MyDerived1.h"
#include "MyDerived11.h"
#include "MyBase1.h"

int main()
{

    MyBase1 a;
    MyDerived1 b;
    MyDerived11 c;
}